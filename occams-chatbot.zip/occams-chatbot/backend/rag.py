"""
RAG (Retrieval Augmented Generation) service
"""
from typing import AsyncGenerator, Optional
from openai import AsyncAzureOpenAI


SYSTEM_PROMPT = """You are the official help assistant for Occams Advisory. Answer as if you ARE Occams Advisory - use "we", "our", and speak directly.

RULES:
1. Answer ONLY based on the provided context - do not make things up
2. Respond directly and confidently. Do NOT start with phrases like "Based on the information..." or "According to the website..."
3. Use "we offer", "our services", "at Occams" - speak as part of the company
4. Be professional, concise, and helpful
5. Use simple bullet points with - for lists, NOT bold (**) formatting
6. Do NOT use markdown bold (**text**) or headers (##) in responses
7. Keep responses clean and easy to read
8. If asked about contact info, only provide what's in the context
9. End with a brief call-to-action: mention scheduling a free consultation at occamsadvisory.com/schedule-a-free-consultation"""


# Acronym expansions for query enhancement
# Maps both compact and spaced versions to full expansion
ACRONYM_EXPANSIONS = {
    # Service acronyms - include spaced version (as on website) + full name
    "BSGI": "B S G I Business Services and Growth Incubation",
    "B S G I": "BSGI Business Services and Growth Incubation",
    "FTPS": "F T P S Financial Technology and Payment Solutions",
    "F T P S": "FTPS Financial Technology and Payment Solutions",
    "CMIB": "C M I B Capital Market and Investment Banking",
    "C M I B": "CMIB Capital Market and Investment Banking",
    "ERC": "E R C Employee Retention Credit",
    "E R C": "ERC Employee Retention Credit",
    "R&D": "Research and Development R and D",
}


def expand_query(query: str) -> str:
    """Expand acronyms in query for better semantic matching"""
    expanded = query
    query_upper = query.upper()
    
    for acronym, expansion in ACRONYM_EXPANSIONS.items():
        # Check if acronym exists in query (case-insensitive)
        if acronym.upper() in query_upper:
            # Add the expansion to the query for better embedding match
            expanded = f"{expanded} {expansion}"
            break  # Only expand once to avoid duplicate expansions
    
    return expanded


class RAGService:
    """RAG service for grounded chatbot responses"""

    def __init__(self, config, vector_store):
        self.config = config
        self.vector_store = vector_store
        self.openai = AsyncAzureOpenAI(
            api_key=config.azure_openai_chat.api_key,
            azure_endpoint=config.azure_openai_chat.endpoint,
            api_version=config.azure_openai_chat.api_version,
        )

    async def stream_response(
        self,
        question: str,
        user_context: Optional[object] = None,
    ) -> AsyncGenerator[dict, None]:
        """Stream a response using RAG"""

        # Step 1: Expand query with acronyms for better matching
        expanded_question = expand_query(question)

        # Step 2: Retrieve relevant documents
        docs = await self.vector_store.search(expanded_question, top_k=self.config.rag.top_k)

        # Step 2: Check if we have relevant context
        if not docs or docs[0]["score"] < self.config.rag.score_threshold:
            yield {
                "type": "content",
                "data": "Sorry, I couldn't find information about that topic. "
                "I can help with questions about Occams Advisory. "
                "Could you ask something about our services, expertise, or offerings?",
            }
            return

        # Step 3: Build context
        context = self._build_context(docs)

        # Step 4: Build user prompt
        user_name = (
            user_context.name if user_context and hasattr(user_context, "name") else ""
        )
        greeting = f"The user's name is {user_name}. " if user_name else ""

        user_prompt = f"""Context from Occams Advisory website:
---
{context}
---

{greeting}User Question: {question}

Please provide a helpful answer based ONLY on the context above."""

        # Step 5: Stream response from Azure OpenAI
        # Note: gpt-5.2-chat only supports default temperature (1), so we don't set it
        try:
            stream = await self.openai.chat.completions.create(
                model=self.config.azure_openai_chat.deployment,
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": user_prompt},
                ],
                max_completion_tokens=self.config.azure_openai_chat.max_tokens,
                stream=True,
            )

            async for chunk in stream:
                # Some chunks may have empty choices list
                if chunk.choices and len(chunk.choices) > 0:
                    delta = chunk.choices[0].delta
                    if delta and delta.content:
                        yield {"type": "content", "data": delta.content}

            # Yield unique sources from retrieved docs (deduplicated)
            seen_urls = set()
            for doc in docs:
                url = doc["metadata"].get("url")
                if url and url not in seen_urls:
                    seen_urls.add(url)
                    yield {"type": "source", "data": url}
                if len(seen_urls) >= 3:  # Limit to top 3 unique sources
                    break

        except Exception as e:
            print(f"❌ Azure OpenAI error: {e}")
            yield {
                "type": "error",
                "data": "I'm having trouble responding right now. Please try again in a moment.",
            }

    async def get_response(
        self,
        question: str,
        user_context: Optional[object] = None,
    ) -> tuple[str, list[str]]:
        """Get non-streaming response"""
        full_response = ""
        sources = []

        async for chunk in self.stream_response(question, user_context):
            if chunk["type"] == "content":
                full_response += chunk["data"]
            elif chunk["type"] == "source":
                sources.append(chunk["data"])

        return full_response, sources

    def _build_context(self, docs: list[dict]) -> str:
        """Build context string from retrieved documents"""
        context_parts = []

        for i, doc in enumerate(docs, 1):
            title = doc["metadata"].get("title", "")
            content = doc["content"]
            context_parts.append(f"[{i}] {title}\n{content}")

        return "\n\n---\n\n".join(context_parts)
