"""
Simple text chunking for RAG
"""
import re
import hashlib
from dataclasses import dataclass


@dataclass
class ContentChunk:
    """A chunk of content for embedding"""

    content: str
    url: str
    title: str
    chunk_id: str


def chunk_pages(
    pages: list, chunk_size: int = 800, overlap: int = 100
) -> list[ContentChunk]:
    """Chunk crawled pages into smaller pieces"""
    all_chunks = []

    for page in pages:
        page_chunks = chunk_text(
            text=page.content,
            url=page.url,
            title=page.title,
            chunk_size=chunk_size,
            overlap=overlap,
        )
        all_chunks.extend(page_chunks)

    print(f"📦 Created {len(all_chunks)} chunks from {len(pages)} pages")
    return all_chunks


def chunk_text(
    text: str,
    url: str,
    title: str,
    chunk_size: int,
    overlap: int,
) -> list[ContentChunk]:
    """Split text into overlapping chunks"""
    chunks = []

    # Clean text
    text = re.sub(r"\s+", " ", text).strip()

    if len(text) <= chunk_size:
        # Text fits in one chunk
        chunk_id = hashlib.md5(f"{url}:0".encode()).hexdigest()[:12]
        return [
            ContentChunk(
                content=text,
                url=url,
                title=title,
                chunk_id=chunk_id,
            )
        ]

    # Split into sentences
    sentences = re.split(r"(?<=[.!?])\s+", text)

    current_chunk = ""
    chunk_index = 0

    for sentence in sentences:
        if len(current_chunk) + len(sentence) <= chunk_size:
            current_chunk += (" " if current_chunk else "") + sentence
        else:
            # Save current chunk
            if current_chunk:
                chunk_id = hashlib.md5(f"{url}:{chunk_index}".encode()).hexdigest()[:12]
                chunks.append(
                    ContentChunk(
                        content=current_chunk,
                        url=url,
                        title=title,
                        chunk_id=chunk_id,
                    )
                )
                chunk_index += 1

            # Start new chunk with overlap
            if overlap > 0 and current_chunk:
                # Take last part of previous chunk
                overlap_text = (
                    current_chunk[-overlap:]
                    if len(current_chunk) > overlap
                    else current_chunk
                )
                current_chunk = overlap_text + " " + sentence
            else:
                current_chunk = sentence

    # Add remaining chunk
    if current_chunk:
        chunk_id = hashlib.md5(f"{url}:{chunk_index}".encode()).hexdigest()[:12]
        chunks.append(
            ContentChunk(
                content=current_chunk,
                url=url,
                title=title,
                chunk_id=chunk_id,
            )
        )

    return chunks
