"""
Occams Advisory Chatbot - FastAPI Backend
All routes in a single file for simplicity
"""
import json
from contextlib import asynccontextmanager
from typing import Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from config import config
from vector_store import VectorStore
from rag import RAGService
from crawler import crawl_website
from leads_db import LeadsDB


# ============== Pydantic Models ==============


class UserContext(BaseModel):
    name: Optional[str] = None
    email: Optional[str] = None
    session_id: Optional[str] = None


class ChatRequest(BaseModel):
    message: str
    user_context: Optional[UserContext] = None


class ChatResponse(BaseModel):
    response: str
    sources: list[str] = []


class LeadCapture(BaseModel):
    name: str
    email: str
    session_id: Optional[str] = None


class LeadResponse(BaseModel):
    id: int
    name: str
    email: str
    created_at: str


# ============== App Lifecycle ==============


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Initialize services on startup"""
    print("🚀 Starting Occams Chatbot API...")

    # Initialize vector store
    app.state.vector_store = VectorStore(config)
    await app.state.vector_store.initialize()

    # Initialize RAG service
    app.state.rag = RAGService(config, app.state.vector_store)

    # Initialize Leads DB
    app.state.leads_db = LeadsDB()
    print(f"✅ Leads DB initialized: {app.state.leads_db.get_lead_count()} leads")

    print("✅ All services initialized")
    yield

    print("👋 Shutting down...")


# ============== FastAPI App ==============

app = FastAPI(
    title="Occams Advisory Chatbot API",
    version="1.0.0",
    lifespan=lifespan,
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=config.server.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ============== Health Endpoints ==============


@app.get("/health")
async def health_check():
    """Basic health check"""
    return {"status": "healthy", "service": "occams-chatbot"}


@app.get("/health/ready")
async def readiness_check():
    """Check if all services are ready"""
    try:
        count = app.state.vector_store.collection.count()
        return {"status": "ready", "vector_store": {"documents": count}}
    except Exception as e:
        return {"status": "degraded", "error": str(e)}


# ============== Chat Endpoints ==============


@app.post("/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    """Non-streaming chat endpoint"""
    if not request.message.strip():
        raise HTTPException(status_code=400, detail="Message cannot be empty")

    response, sources = await app.state.rag.get_response(
        question=request.message, user_context=request.user_context
    )

    return ChatResponse(response=response, sources=sources)


@app.post("/chat/stream")
async def chat_stream(request: ChatRequest):
    """Streaming chat endpoint using SSE"""
    if not request.message.strip():
        raise HTTPException(status_code=400, detail="Message cannot be empty")

    async def generate():
        try:
            async for chunk in app.state.rag.stream_response(
                question=request.message, user_context=request.user_context
            ):
                yield f"data: {json.dumps(chunk)}\n\n"
            yield f"data: {json.dumps({'type': 'done'})}\n\n"
        except Exception as e:
            yield f"data: {json.dumps({'type': 'error', 'data': str(e)})}\n\n"

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
        },
    )


# ============== Crawler Endpoint ==============


@app.post("/crawl")
async def trigger_crawl():
    """Manually trigger website crawl and indexing"""
    try:
        # Run crawler
        pages = await crawl_website(config)

        if not pages:
            return {"status": "warning", "message": "No pages crawled"}

        # Index pages
        count = await app.state.vector_store.ingest_pages(pages)

        return {
            "status": "success",
            "pages_crawled": len(pages),
            "chunks_indexed": count,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Crawl failed: {str(e)}")


# ============== Leads Endpoints ==============


@app.post("/leads", response_model=LeadResponse)
async def capture_lead(lead: LeadCapture):
    """Capture a new lead from chatbot signup"""
    try:
        saved_lead = app.state.leads_db.add_lead(
            name=lead.name,
            email=lead.email,
            session_id=lead.session_id
        )
        return LeadResponse(
            id=saved_lead.id,
            name=saved_lead.name,
            email=saved_lead.email,
            created_at=str(saved_lead.created_at)
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.get("/leads")
async def get_leads():
    """Get all captured leads (admin endpoint)"""
    leads = app.state.leads_db.get_all_leads()
    return {
        "total": len(leads),
        "leads": [
            {
                "id": lead.id,
                "name": lead.name,
                "email": lead.email,
                "session_id": lead.session_id,
                "created_at": str(lead.created_at)
            }
            for lead in leads
        ]
    }


@app.get("/leads/count")
async def get_lead_count():
    """Get lead count"""
    return {"count": app.state.leads_db.get_lead_count()}


# ============== Run Server ==============

if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "main:app",
        host=config.server.host,
        port=config.server.port,
        reload=True,
    )
