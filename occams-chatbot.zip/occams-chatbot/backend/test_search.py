import asyncio
import sys
sys.path.insert(0, '.')
from config import load_config
from vector_store import VectorStore

async def test():
    config = load_config()
    vs = VectorStore(config)
    await vs.initialize()
    
    query = 'What is BSGI?'
    results = await vs.search(query, top_k=5)
    
    print(f'Query: {query}')
    print(f'Score threshold in config: {config.rag.score_threshold}')
    print(f'Found {len(results)} results\n')
    
    for i, r in enumerate(results):
        score = r.get('score', 0)
        url = r.get('metadata', {}).get('url', 'N/A')
        content = r.get('content', '')[:200]
        print(f'{i+1}. Score: {score:.4f}')
        print(f'   URL: {url}')
        print(f'   Content: {content}...\n')

asyncio.run(test())
