"""
Simple configuration loader for Occams Chatbot
"""
import os
import yaml
from dataclasses import dataclass
from typing import List
from dotenv import load_dotenv

# Load .env file
load_dotenv()


@dataclass
class AzureOpenAIChatConfig:
    api_key: str
    endpoint: str
    api_version: str
    deployment: str
    max_tokens: int
    temperature: float


@dataclass
class AzureOpenAIEmbeddingConfig:
    api_key: str
    endpoint: str
    api_version: str
    deployment: str


@dataclass
class CrawlerConfig:
    base_url: str
    max_depth: int
    max_pages: int
    timeout: int


@dataclass
class VectorStoreConfig:
    persist_directory: str
    collection_name: str


@dataclass
class RAGConfig:
    chunk_size: int
    chunk_overlap: int
    top_k: int
    score_threshold: float


@dataclass
class ServerConfig:
    host: str
    port: int
    cors_origins: List[str]


@dataclass
class Config:
    azure_openai_chat: AzureOpenAIChatConfig
    azure_openai_embedding: AzureOpenAIEmbeddingConfig
    crawler: CrawlerConfig
    vectorstore: VectorStoreConfig
    rag: RAGConfig
    server: ServerConfig


def load_config(path: str = "config.yaml") -> Config:
    """Load configuration from YAML file"""
    with open(path, "r") as f:
        data = yaml.safe_load(f)

    # Load Chat API key from environment if specified as "env"
    chat_api_key = data["azure_openai_chat"]["api_key"]
    if chat_api_key == "env":
        chat_api_key = os.getenv("AZURE_OPENAI_CHAT_API_KEY", "")
        if not chat_api_key:
            print("⚠️  Warning: AZURE_OPENAI_CHAT_API_KEY not found in environment")

    # Load Embedding API key from environment if specified as "env"
    embedding_api_key = data["azure_openai_embedding"]["api_key"]
    if embedding_api_key == "env":
        embedding_api_key = os.getenv("AZURE_OPENAI_EMBEDDING_API_KEY", "")
        if not embedding_api_key:
            print("⚠️  Warning: AZURE_OPENAI_EMBEDDING_API_KEY not found in environment")

    return Config(
        azure_openai_chat=AzureOpenAIChatConfig(
            api_key=chat_api_key,
            endpoint=data["azure_openai_chat"]["endpoint"],
            api_version=data["azure_openai_chat"]["api_version"],
            deployment=data["azure_openai_chat"]["deployment"],
            max_tokens=data["azure_openai_chat"]["max_tokens"],
            temperature=data["azure_openai_chat"]["temperature"],
        ),
        azure_openai_embedding=AzureOpenAIEmbeddingConfig(
            api_key=embedding_api_key,
            endpoint=data["azure_openai_embedding"]["endpoint"],
            api_version=data["azure_openai_embedding"]["api_version"],
            deployment=data["azure_openai_embedding"]["deployment"],
        ),
        crawler=CrawlerConfig(
            base_url=data["crawler"]["base_url"],
            max_depth=data["crawler"]["max_depth"],
            max_pages=data["crawler"]["max_pages"],
            timeout=data["crawler"]["timeout"],
        ),
        vectorstore=VectorStoreConfig(
            persist_directory=data["vectorstore"]["persist_directory"],
            collection_name=data["vectorstore"]["collection_name"],
        ),
        rag=RAGConfig(
            chunk_size=data["rag"]["chunk_size"],
            chunk_overlap=data["rag"]["chunk_overlap"],
            top_k=data["rag"]["top_k"],
            score_threshold=data["rag"]["score_threshold"],
        ),
        server=ServerConfig(
            host=data["server"]["host"],
            port=data["server"]["port"],
            cors_origins=data["server"]["cors_origins"],
        ),
    )


# Global config instance
config = load_config()
