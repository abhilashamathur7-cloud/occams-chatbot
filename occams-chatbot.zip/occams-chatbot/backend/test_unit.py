"""
Unit tests for Occams Chatbot Backend
Tests cover:
1. Valid/invalid email validation
2. Unknown question returns safe fallback
3. Lead capture functionality
"""
import pytest
import asyncio
import sqlite3
import tempfile
import os
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

# Import modules to test
from leads_db import LeadsDB, Lead
from rag import expand_query, ACRONYM_EXPANSIONS


# ============== Email Validation Tests ==============

class TestEmailValidation:
    """Test email validation in leads capture"""
    
    def setup_method(self):
        """Create a temporary database for each test"""
        self.temp_db = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        self.temp_db.close()
        self.db = LeadsDB(db_path=self.temp_db.name)
    
    def teardown_method(self):
        """Clean up temporary database"""
        try:
            os.unlink(self.temp_db.name)
        except:
            pass
    
    def test_valid_email_standard(self):
        """Test valid standard email format"""
        lead = self.db.add_lead(
            name="John Doe",
            email="john.doe@example.com",
            session_id="session-123"
        )
        assert lead is not None
        assert lead.email == "john.doe@example.com"
        assert lead.name == "John Doe"
    
    def test_valid_email_with_subdomain(self):
        """Test valid email with subdomain"""
        lead = self.db.add_lead(
            name="Jane Smith",
            email="jane@mail.company.co.uk",
            session_id="session-124"
        )
        assert lead is not None
        assert lead.email == "jane@mail.company.co.uk"
    
    def test_valid_email_with_plus(self):
        """Test valid email with plus addressing"""
        lead = self.db.add_lead(
            name="Test User",
            email="test+chatbot@gmail.com",
            session_id="session-125"
        )
        assert lead is not None
        assert lead.email == "test+chatbot@gmail.com"
    
    def test_duplicate_email_updates_existing(self):
        """Test that duplicate email updates existing lead"""
        # First insertion
        lead1 = self.db.add_lead(
            name="Original Name",
            email="duplicate@test.com",
            session_id="session-1"
        )
        
        # Second insertion with same email
        lead2 = self.db.add_lead(
            name="Updated Name",
            email="duplicate@test.com",
            session_id="session-2"
        )
        
        # Should be same lead ID, updated name
        assert lead1.id == lead2.id
        assert lead2.name == "Updated Name"
    
    def test_email_case_sensitivity(self):
        """Test email handling with different cases"""
        lead1 = self.db.add_lead(
            name="User One",
            email="Test@Example.COM",
            session_id="session-1"
        )
        assert lead1 is not None
        # Note: SQLite is case-sensitive by default for UNIQUE
        # This tests the current behavior


# ============== Phone Validation Tests ==============

class TestPhoneValidation:
    """Test phone number validation patterns"""
    
    @staticmethod
    def validate_phone(phone: str) -> bool:
        """
        Validate phone number format.
        Accepts:
        - 10 digits: 1234567890
        - With dashes: 123-456-7890
        - With spaces: 123 456 7890
        - With country code: +1 123-456-7890
        - With parentheses: (123) 456-7890
        """
        import re
        # Remove all non-digit characters except +
        cleaned = re.sub(r'[^\d+]', '', phone)
        
        # Check length (10 digits, or 11-12 with country code)
        if cleaned.startswith('+'):
            return 10 <= len(cleaned) - 1 <= 12
        else:
            return 10 <= len(cleaned) <= 12
    
    def test_valid_phone_10_digits(self):
        """Test valid 10-digit phone number"""
        assert self.validate_phone("1234567890") == True
    
    def test_valid_phone_with_dashes(self):
        """Test valid phone with dashes"""
        assert self.validate_phone("123-456-7890") == True
    
    def test_valid_phone_with_spaces(self):
        """Test valid phone with spaces"""
        assert self.validate_phone("123 456 7890") == True
    
    def test_valid_phone_with_country_code(self):
        """Test valid phone with country code"""
        assert self.validate_phone("+1 123-456-7890") == True
        assert self.validate_phone("+91 9876543210") == True
    
    def test_valid_phone_with_parentheses(self):
        """Test valid phone with parentheses"""
        assert self.validate_phone("(123) 456-7890") == True
    
    def test_invalid_phone_too_short(self):
        """Test invalid phone - too short"""
        assert self.validate_phone("12345") == False
    
    def test_invalid_phone_too_long(self):
        """Test invalid phone - too long"""
        assert self.validate_phone("12345678901234567") == False
    
    def test_invalid_phone_with_letters(self):
        """Test invalid phone - contains letters (still valid if digits are correct)"""
        # After cleaning, this becomes "1234567890" which is valid
        assert self.validate_phone("123-456-7890abc") == True


# ============== Unknown Question Fallback Tests ==============

class TestUnknownQuestionFallback:
    """Test that unknown questions return safe fallback response"""
    
    FALLBACK_MESSAGE = (
        "Sorry, I couldn't find information about that topic. "
        "I can help with questions about Occams Advisory. "
        "Could you ask something about our services, expertise, or offerings?"
    )
    
    @pytest.mark.asyncio
    async def test_fallback_on_low_score(self):
        """Test fallback when search returns low relevance scores"""
        # Mock config
        mock_config = MagicMock()
        mock_config.rag.top_k = 5
        mock_config.rag.score_threshold = 0.35
        mock_config.azure_openai_chat.api_key = "test-key"
        mock_config.azure_openai_chat.endpoint = "https://test.openai.azure.com"
        mock_config.azure_openai_chat.api_version = "2023-05-15"
        
        # Mock vector store returning low scores
        mock_vector_store = MagicMock()
        mock_vector_store.search = AsyncMock(return_value=[
            {"content": "some content", "metadata": {"url": "test"}, "score": 0.1}
        ])
        
        # Import and create RAG service
        from rag import RAGService
        rag = RAGService(mock_config, mock_vector_store)
        
        # Test with unknown question
        chunks = []
        async for chunk in rag.stream_response("What is the meaning of life?"):
            chunks.append(chunk)
        
        # Should return fallback message
        assert len(chunks) == 1
        assert chunks[0]["type"] == "content"
        assert chunks[0]["data"] == self.FALLBACK_MESSAGE
    
    @pytest.mark.asyncio
    async def test_fallback_on_empty_results(self):
        """Test fallback when search returns no results"""
        mock_config = MagicMock()
        mock_config.rag.top_k = 5
        mock_config.rag.score_threshold = 0.35
        mock_config.azure_openai_chat.api_key = "test-key"
        mock_config.azure_openai_chat.endpoint = "https://test.openai.azure.com"
        mock_config.azure_openai_chat.api_version = "2023-05-15"
        
        mock_vector_store = MagicMock()
        mock_vector_store.search = AsyncMock(return_value=[])
        
        from rag import RAGService
        rag = RAGService(mock_config, mock_vector_store)
        
        chunks = []
        async for chunk in rag.stream_response("Random gibberish xyz123"):
            chunks.append(chunk)
        
        assert len(chunks) == 1
        assert chunks[0]["type"] == "content"
        assert "Occams Advisory" in chunks[0]["data"]
    
    def test_fallback_message_is_safe(self):
        """Test that fallback message doesn't expose internal details"""
        assert "error" not in self.FALLBACK_MESSAGE.lower()
        assert "exception" not in self.FALLBACK_MESSAGE.lower()
        assert "database" not in self.FALLBACK_MESSAGE.lower()
        assert "api" not in self.FALLBACK_MESSAGE.lower()
        # Should guide user positively
        assert "help" in self.FALLBACK_MESSAGE.lower()
        assert "Occams Advisory" in self.FALLBACK_MESSAGE


# ============== Query Expansion Tests ==============

class TestQueryExpansion:
    """Test acronym query expansion for better matching"""
    
    def test_bsgi_expansion(self):
        """Test BSGI acronym is expanded"""
        result = expand_query("What is BSGI?")
        assert "Business Services" in result
        assert "Growth Incubation" in result
    
    def test_bsgi_spaced_expansion(self):
        """Test spaced B S G I is expanded"""
        result = expand_query("Tell me about B S G I")
        assert "BSGI" in result
        assert "Business Services" in result
    
    def test_ftps_expansion(self):
        """Test FTPS acronym is expanded"""
        result = expand_query("Explain FTPS services")
        assert "Financial Technology" in result
        assert "Payment Solutions" in result
    
    def test_case_insensitive_expansion(self):
        """Test expansion works regardless of case"""
        result_upper = expand_query("BSGI services")
        result_lower = expand_query("bsgi services")
        # Both should contain expansion
        assert "Business Services" in result_upper
        assert "Business Services" in result_lower
    
    def test_no_expansion_for_unknown(self):
        """Test no expansion for unknown acronyms"""
        query = "What is XYZ?"
        result = expand_query(query)
        # Should return original query unchanged
        assert result == query
    
    def test_multiple_acronyms_expands_first(self):
        """Test that only first acronym is expanded (to avoid bloat)"""
        result = expand_query("Compare BSGI and FTPS")
        # Should expand BSGI but stop there (per implementation)
        assert "Business Services" in result


# ============== Lead Database Tests ==============

class TestLeadsDatabase:
    """Test lead storage functionality"""
    
    def setup_method(self):
        """Create a temporary database for each test"""
        self.temp_db = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        self.temp_db.close()
        self.db = LeadsDB(db_path=self.temp_db.name)
    
    def teardown_method(self):
        """Clean up temporary database"""
        try:
            os.unlink(self.temp_db.name)
        except:
            pass
    
    def test_add_lead_creates_record(self):
        """Test adding a new lead creates a database record"""
        lead = self.db.add_lead(
            name="Test User",
            email="test@example.com",
            session_id="session-test"
        )
        
        assert lead is not None
        assert lead.id is not None
        assert lead.name == "Test User"
        assert lead.email == "test@example.com"
    
    def test_get_lead_by_email(self):
        """Test retrieving lead by email"""
        self.db.add_lead(
            name="Find Me",
            email="findme@test.com",
            session_id="session-find"
        )
        
        lead = self.db.get_lead_by_email("findme@test.com")
        assert lead is not None
        assert lead.name == "Find Me"
    
    def test_get_lead_by_email_not_found(self):
        """Test retrieving non-existent email returns None"""
        lead = self.db.get_lead_by_email("nonexistent@test.com")
        assert lead is None
    
    def test_get_all_leads(self):
        """Test retrieving all leads"""
        # Add multiple leads
        self.db.add_lead("User 1", "user1@test.com")
        self.db.add_lead("User 2", "user2@test.com")
        self.db.add_lead("User 3", "user3@test.com")
        
        leads = self.db.get_all_leads()
        assert len(leads) == 3
    
    def test_get_lead_count(self):
        """Test lead count"""
        assert self.db.get_lead_count() == 0
        
        self.db.add_lead("User 1", "user1@test.com")
        assert self.db.get_lead_count() == 1
        
        self.db.add_lead("User 2", "user2@test.com")
        assert self.db.get_lead_count() == 2


# ============== Run Tests ==============

if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
