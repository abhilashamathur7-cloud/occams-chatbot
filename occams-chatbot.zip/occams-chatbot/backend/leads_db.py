"""
SQLite database for lead storage
"""
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Optional
from dataclasses import dataclass

DB_PATH = Path(__file__).parent / "leads.db"


@dataclass
class Lead:
    id: int
    name: str
    email: str
    session_id: Optional[str]
    source: str
    created_at: datetime


class LeadsDB:
    def __init__(self, db_path: str = str(DB_PATH)):
        self.db_path = db_path
        self._init_db()

    def _init_db(self):
        """Initialize database tables"""
        with sqlite3.connect(self.db_path) as conn:
            conn.executescript('''
                CREATE TABLE IF NOT EXISTS leads (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    email TEXT NOT NULL UNIQUE,
                    session_id TEXT,
                    source TEXT DEFAULT 'chatbot',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );

                CREATE TABLE IF NOT EXISTS chat_sessions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id TEXT UNIQUE NOT NULL,
                    lead_id INTEGER,
                    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    last_active_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    message_count INTEGER DEFAULT 0,
                    FOREIGN KEY (lead_id) REFERENCES leads(id)
                );

                CREATE INDEX IF NOT EXISTS idx_leads_email ON leads(email);
                CREATE INDEX IF NOT EXISTS idx_sessions_session_id ON chat_sessions(session_id);
            ''')

    def add_lead(self, name: str, email: str, session_id: Optional[str] = None) -> Lead:
        """Add a new lead or update existing"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()

            # Check if email exists
            cursor.execute("SELECT id FROM leads WHERE email = ?", (email,))
            existing = cursor.fetchone()

            if existing:
                # Update existing lead
                cursor.execute('''
                    UPDATE leads 
                    SET name = ?, session_id = ?, updated_at = CURRENT_TIMESTAMP
                    WHERE email = ?
                ''', (name, session_id, email))
                lead_id = existing[0]
            else:
                # Insert new lead
                cursor.execute('''
                    INSERT INTO leads (name, email, session_id, source)
                    VALUES (?, ?, ?, 'chatbot')
                ''', (name, email, session_id))
                lead_id = cursor.lastrowid

            conn.commit()

            # Link session to lead if session_id provided
            if session_id:
                cursor.execute('''
                    INSERT INTO chat_sessions (session_id, lead_id)
                    VALUES (?, ?)
                    ON CONFLICT(session_id) DO UPDATE SET lead_id = ?
                ''', (session_id, lead_id, lead_id))
                conn.commit()

            return self.get_lead_by_id(lead_id)

    def get_lead_by_email(self, email: str) -> Optional[Lead]:
        """Get lead by email"""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM leads WHERE email = ?", (email,))
            row = cursor.fetchone()
            if row:
                return Lead(
                    id=row['id'],
                    name=row['name'],
                    email=row['email'],
                    session_id=row['session_id'],
                    source=row['source'],
                    created_at=row['created_at']
                )
        return None

    def get_lead_by_id(self, lead_id: int) -> Optional[Lead]:
        """Get lead by ID"""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM leads WHERE id = ?", (lead_id,))
            row = cursor.fetchone()
            if row:
                return Lead(
                    id=row['id'],
                    name=row['name'],
                    email=row['email'],
                    session_id=row['session_id'],
                    source=row['source'],
                    created_at=row['created_at']
                )
        return None

    def get_all_leads(self) -> list[Lead]:
        """Get all leads"""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM leads ORDER BY created_at DESC")
            return [
                Lead(
                    id=row['id'],
                    name=row['name'],
                    email=row['email'],
                    session_id=row['session_id'],
                    source=row['source'],
                    created_at=row['created_at']
                )
                for row in cursor.fetchall()
            ]

    def get_lead_count(self) -> int:
        """Get total lead count"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM leads")
            return cursor.fetchone()[0]
