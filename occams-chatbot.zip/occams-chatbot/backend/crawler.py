"""
Website crawler using Playwright for JS-rendered content
Uses sync API to avoid Windows asyncio subprocess issues

NOTE: Do NOT use browser.new_context() with custom user_agent as it causes 
403 Forbidden errors. The website detects incomplete browser fingerprinting.
Use browser.new_page() directly which includes full default fingerprinting.
"""
import asyncio
from dataclasses import dataclass, field
from urllib.parse import urljoin, urlparse
from typing import Set
from concurrent.futures import ThreadPoolExecutor

from playwright.sync_api import sync_playwright


@dataclass
class CrawledPage:
    """Represents a crawled page"""

    url: str
    title: str
    content: str
    headings: list[dict] = field(default_factory=list)


def _crawl_sync(config) -> list[CrawledPage]:
    """Synchronous crawl function to run in thread"""
    base_url = config.crawler.base_url
    max_depth = config.crawler.max_depth
    max_pages = config.crawler.max_pages
    timeout = config.crawler.timeout

    visited: Set[str] = set()
    pages: list[CrawledPage] = []

    with sync_playwright() as p:
        # Launch browser - do NOT use new_context() with custom user_agent
        # as it causes 403 Forbidden (incomplete browser fingerprinting detected)
        browser = p.chromium.launch(headless=True)

        def crawl_page(url: str, depth: int):
            """Recursively crawl a single page"""
            nonlocal pages

            if depth > max_depth or len(pages) >= max_pages:
                return
            if url in visited:
                return

            # Normalize URL - strip www, keep query params for pagination
            parsed = urlparse(url)
            netloc = parsed.netloc.replace('www.', '').lower()
            # Handle trailing slash consistently - always remove it for normalization
            path = parsed.path.rstrip("/") if parsed.path != "/" else ""
            # Keep query params for pagination (e.g., ?page=2)
            query = f"?{parsed.query}" if parsed.query else ""
            normalized = f"{parsed.scheme.lower()}://{netloc}{path}{query}"

            if normalized in visited:
                print(f"⏭️ Already visited: {normalized}")
                return
            visited.add(normalized)
            
            print(f"🔍 Attempting to crawl (depth={depth}): {url} -> normalized: {normalized}")

            try:
                # Use browser.new_page() directly - NOT context.new_page()
                # Custom contexts with partial user_agent trigger 403 Forbidden
                page = browser.new_page()
                # Use 'load' - simpler and more reliable for this site
                # (networkidle times out due to persistent connections)
                page.goto(url, timeout=timeout, wait_until="load")
                
                # Give JS time to render dynamic content
                page.wait_for_timeout(5000)
                
                # Debug: Check what's on the page
                print("DBG title:", page.title())
                print("DBG anchors:", page.evaluate("() => document.querySelectorAll('a').length"))
                print("DBG anchors_with_href:", page.evaluate("() => document.querySelectorAll('a[href]').length"))
                print("DBG buttons:", page.evaluate("() => document.querySelectorAll('button').length"))
                print("DBG frames:", len(page.frames))

                # Extract content
                title = page.title()

                # Get all text content (keep nav for link discovery but clean for content)
                content = page.evaluate(
                    """
                    () => {
                        // Clone body to avoid modifying original
                        const clone = document.body.cloneNode(true);
                        // Remove scripts, styles
                        const remove = clone.querySelectorAll('script, style, noscript, iframe');
                        remove.forEach(el => el.remove());
                        
                        // Get text content
                        return clone.innerText;
                    }
                """
                )

                # Get headings
                headings = page.evaluate(
                    """
                    () => {
                        const headings = [];
                        document.querySelectorAll('h1, h2, h3').forEach(h => {
                            headings.push({
                                level: h.tagName,
                                text: h.innerText.trim()
                            });
                        });
                        return headings;
                    }
                """
                )

                # Store page
                if content.strip():
                    pages.append(
                        CrawledPage(
                            url=normalized,
                            title=title,
                            content=content.strip(),
                            headings=headings,
                        )
                    )
                    print(f"✅ Crawled: {normalized}")

                # Find internal links using JS to penetrate Shadow DOM
                # Properly handles hash links and preserves query params for pagination
                links = set()
                try:
                    raw_links = page.evaluate("""
                        () => {
                            const out = new Set();
                            
                            const add = (href) => {
                                if (!href) return;
                                
                                const s = String(href).trim();
                                const low = s.toLowerCase();
                                if (low.startsWith('mailto:') || low.startsWith('tel:') || low.startsWith('javascript:')) return;
                                if (s.startsWith('#')) return; // same-page section jump
                                
                                try {
                                    const u = new URL(s, window.location.href);
                                    const cur = new URL(window.location.href);
                                    
                                    // If it's the same document and only differs by hash, ignore it.
                                    const sameDocHashOnly =
                                        u.origin === cur.origin &&
                                        u.pathname === cur.pathname &&
                                        u.hash &&
                                        u.search === cur.search;
                                    
                                    if (sameDocHashOnly) return;
                                    
                                    // Keep query params (pagination), drop hash
                                    u.hash = '';
                                    out.add(u.toString());
                                } catch (e) {
                                    // ignore malformed URLs
                                }
                            };
                            
                            const walk = (node) => {
                                if (!node) return;
                                if (node.tagName === 'A') add(node.getAttribute('href') || node.href);
                                
                                if (node.shadowRoot) [...node.shadowRoot.childNodes].forEach(walk);
                                if (node.childNodes) [...node.childNodes].forEach(walk);
                            };
                            
                            walk(document.body);
                            return Array.from(out);
                        }
                    """)
                    links = set(raw_links) if raw_links else set()
                except Exception as e:
                    print(f"⚠️ Error extracting links via JS: {e}")
                    # Fallback to query selector
                    try:
                        anchors = page.query_selector_all('a[href]')
                        for anchor in anchors:
                            href = anchor.get_attribute('href')
                            if href and not href.startswith('#') and not href.startswith('mailto:') and not href.startswith('tel:') and not href.startswith('javascript:'):
                                href = href.split('#')[0].split('?')[0]
                                if href:
                                    links.add(href)
                    except Exception as e2:
                        print(f"⚠️ Fallback link extraction also failed: {e2}")

                page.close()
                
                print(f"📎 Found {len(links)} links on {url}")
                # Debug: Show sample links to verify extraction is working
                sample_links = list(links)[:15]
                print(f"📋 Sample links: {sample_links}")

                # Crawl child pages
                base_parsed = urlparse(base_url)
                base_domain = base_parsed.netloc.replace('www.', '').lower()
                matched_links = 0
                rejected_links = 0
                for link in links:
                    full_url = urljoin(url, link)
                    link_parsed = urlparse(full_url)
                    link_domain = link_parsed.netloc.replace('www.', '')
                    # Stay on same domain or subdomains (handle www vs non-www and subdomains)
                    # e.g., blog.example.com matches example.com
                    is_same_domain = link_domain == base_domain
                    is_subdomain = link_domain.endswith(f".{base_domain}")
                    
                    if (is_same_domain or is_subdomain) and link_parsed.scheme in ('http', 'https'):
                        matched_links += 1
                        crawl_page(full_url, depth + 1)
                    else:
                        rejected_links += 1
                        # Debug: Log why link was rejected (only first 10 to avoid spam)
                        if rejected_links <= 10:
                            if link_parsed.scheme not in ('http', 'https'):
                                print(f"🚫 Rejected: {full_url} - Reason: Invalid scheme '{link_parsed.scheme}'")
                            else:
                                print(f"🚫 Rejected: {full_url} - Reason: Domain mismatch ('{link_domain}' not in '{base_domain}')")
                
                print(f"🔗 {matched_links} internal links matched, {rejected_links} rejected from {url}")

            except Exception as e:
                print(f"❌ Error crawling {url}: {e}")

        # Start crawling from the homepage and discover links recursively
        print(f"🕷️ Starting full website crawl of {base_url}")
        print(f"📊 Settings: max_depth={max_depth}, max_pages={max_pages}")
        crawl_page(base_url, 0)
        
        browser.close()

    print(f"📊 Crawled {len(pages)} pages total")
    return pages


async def crawl_website(config) -> list[CrawledPage]:
    """Crawl website - runs sync Playwright in a thread to avoid Windows asyncio issues"""
    loop = asyncio.get_event_loop()
    with ThreadPoolExecutor() as executor:
        pages = await loop.run_in_executor(executor, _crawl_sync, config)
    return pages
