"""
ChromaDB vector store - simple file-based vector database
"""
import chromadb
from chromadb.config import Settings
from openai import AsyncAzureOpenAI

from chunker import chunk_pages


class VectorStore:
    """ChromaDB-based vector store with Azure OpenAI embeddings"""

    def __init__(self, config):
        self.config = config
        self.openai = AsyncAzureOpenAI(
            api_key=config.azure_openai_embedding.api_key,
            azure_endpoint=config.azure_openai_embedding.endpoint,
            api_version=config.azure_openai_embedding.api_version,
        )
        self.client = None
        self.collection = None

    async def initialize(self):
        """Initialize ChromaDB collection"""
        self.client = chromadb.PersistentClient(
            path=self.config.vectorstore.persist_directory,
            settings=Settings(anonymized_telemetry=False),
        )

        self.collection = self.client.get_or_create_collection(
            name=self.config.vectorstore.collection_name,
            metadata={"description": "Occams Advisory website content", "hnsw:space": "cosine"},
        )

        print(f"✅ Vector store initialized: {self.collection.count()} documents")

    async def ingest_pages(self, pages: list) -> int:
        """Process pages and store in vector DB"""
        # Chunk the pages
        chunks = chunk_pages(
            pages,
            chunk_size=self.config.rag.chunk_size,
            overlap=self.config.rag.chunk_overlap,
        )

        if not chunks:
            return 0

        # Clear existing data
        self.client.delete_collection(self.config.vectorstore.collection_name)
        self.collection = self.client.create_collection(
            name=self.config.vectorstore.collection_name,
            metadata={"hnsw:space": "cosine"},
        )

        # Generate embeddings and store
        for i, chunk in enumerate(chunks):
            try:
                # Get embedding from Azure OpenAI
                response = await self.openai.embeddings.create(
                    model=self.config.azure_openai_embedding.deployment, input=chunk.content
                )
                embedding = response.data[0].embedding

                # Add to ChromaDB
                self.collection.add(
                    ids=[f"chunk_{chunk.chunk_id}"],
                    embeddings=[embedding],
                    documents=[chunk.content],
                    metadatas=[{"url": chunk.url, "title": chunk.title}],
                )

                if (i + 1) % 10 == 0:
                    print(f"📝 Embedded {i + 1}/{len(chunks)} chunks")

            except Exception as e:
                print(f"❌ Error embedding chunk {i}: {e}")

        print(f"✅ Stored {len(chunks)} chunks in vector DB")
        return len(chunks)

    async def search(self, query: str, top_k: int = 5) -> list[dict]:
        """Search for similar documents"""
        # Get query embedding
        response = await self.openai.embeddings.create(
            model=self.config.azure_openai_embedding.deployment, input=query
        )
        query_embedding = response.data[0].embedding

        # Search ChromaDB
        results = self.collection.query(
            query_embeddings=[query_embedding],
            n_results=top_k,
            include=["documents", "metadatas", "distances"],
        )

        # Format results
        documents = []
        if results["ids"] and results["ids"][0]:
            for i in range(len(results["ids"][0])):
                score = 1 - results["distances"][0][i]  # Convert distance to similarity
                documents.append(
                    {
                        "content": results["documents"][0][i],
                        "metadata": results["metadatas"][0][i],
                        "score": score,
                    }
                )

        return documents
