import { useState, useEffect } from 'react';
import ChatWidget from './components/ChatWidget';
import { UserContext } from './types';

const USER_STORAGE_KEY = 'occams_user';

function App() {
  const [userContext, setUserContext] = useState<UserContext | null>(null);

  useEffect(() => {
    // Load or create session
    const stored = localStorage.getItem(USER_STORAGE_KEY);
    if (stored) {
      setUserContext(JSON.parse(stored));
    } else {
      const newContext: UserContext = {
        name: '',
        email: '',
        sessionId: `session-${Date.now()}`,
      };
      setUserContext(newContext);
      localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(newContext));
    }
  }, []);

  const handleUserSignup = (name: string, email: string) => {
    if (!userContext) return;
    
    const updatedContext: UserContext = {
      ...userContext,
      name,
      email,
      signedUpAt: new Date().toISOString(),
    };
    
    setUserContext(updatedContext);
    localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(updatedContext));
  };

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-800 mb-4">
          Welcome to Occams Advisory
        </h1>
        <p className="text-gray-600 mb-6">
          This is a demo page. The AI chat assistant is available in the
          bottom-right corner. Click the chat icon to start a conversation.
        </p>

        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <h2 className="text-xl font-semibold text-gray-700 mb-3">
            About Our Chatbot
          </h2>
          <ul className="list-disc list-inside text-gray-600 space-y-2">
            <li>Ask questions about Occams Advisory services</li>
            <li>Get information from our website content</li>
            <li>Receive real-time streaming responses</li>
            <li>View source links for answers</li>
          </ul>
        </div>

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <p className="text-blue-800 text-sm">
            <strong>Note:</strong> Make sure the backend server is running and
            the website has been crawled before testing the chatbot.
          </p>
        </div>
      </div>

      <ChatWidget userContext={userContext} onUserSignup={handleUserSignup} />
    </div>
  );
}

export default App;
