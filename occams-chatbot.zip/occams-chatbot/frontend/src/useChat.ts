import { useState, useCallback, useEffect } from 'react';
import { Message, UserContext, StreamChunk, SignupState } from './types';
import { streamChat } from './api';

const SIGNUP_STATE_KEY = 'occams_signup_state';

function getInitialSignupState(): SignupState {
  const stored = localStorage.getItem(SIGNUP_STATE_KEY);
  if (stored) {
    const parsed = JSON.parse(stored);
    // Reset responseCount on page reload (fresh session), but keep dismissCount and hasSignedUp
    return {
      ...parsed,
      responseCount: 0,
      lastPromptAt: 0,
    };
  }
  return {
    hasSignedUp: false,
    dismissCount: 0,
    responseCount: 0,
    lastPromptAt: 0,
  };
}

function saveSignupState(state: SignupState) {
  localStorage.setItem(SIGNUP_STATE_KEY, JSON.stringify(state));
}

function getWelcomeMessage(userName?: string): Message {
  const greeting = userName
    ? `Welcome back, ${userName}! 👋 How can I help you today?`
    : 'Welcome to Occams Advisory! 👋 How can I help you today? Feel free to ask about our services, expertise, or anything else.';
  
  return {
    id: 'welcome',
    role: 'assistant',
    content: greeting,
    timestamp: new Date(),
  };
}

export function useChat(userContext: UserContext | null) {
  const [signupState, setSignupState] = useState<SignupState>(() => {
    const initial = getInitialSignupState();
    // Check if user already signed up (has email in context)
    if (userContext?.email) {
      initial.hasSignedUp = true;
    }
    return initial;
  });

  // Initialize with welcome message
  const [messages, setMessages] = useState<Message[]>([
    getWelcomeMessage(userContext?.name),
  ]);
  const [isLoading, setIsLoading] = useState(false);

  // Update welcome message when userContext changes
  useEffect(() => {
    if (userContext?.name && messages[0]?.id === 'welcome') {
      setMessages((prev) => {
        const updated = [...prev];
        updated[0] = getWelcomeMessage(userContext.name);
        return updated;
      });
    }
    // Update signup state when user has signed up
    if (userContext?.email && !signupState.hasSignedUp) {
      const newState = { ...signupState, hasSignedUp: true };
      setSignupState(newState);
      saveSignupState(newState);
    }
  }, [userContext?.name, userContext?.email]);

  const shouldShowSignupForm = useCallback(
    (currentResponseCount: number): boolean => {
      // Don't show if already signed up
      if (signupState.hasSignedUp || userContext?.email) return false;
      
      // Don't show if dismissed 2 times
      if (signupState.dismissCount >= 2) return false;
      
      // Show after 2nd response (first time)
      if (currentResponseCount === 2 && signupState.dismissCount === 0) {
        return true;
      }
      
      // Show after 5th response (if dismissed once)
      if (currentResponseCount === 5 && signupState.dismissCount === 1) {
        return true;
      }
      
      return false;
    },
    [signupState, userContext?.email]
  );

  const injectSignupForm = useCallback(() => {
    const signupMessage: Message = {
      id: `signup-${Date.now()}`,
      role: 'assistant',
      content: '',
      timestamp: new Date(),
      isSignupForm: true,
    };
    setMessages((prev) => [...prev, signupMessage]);
  }, []);

  const handleSignupDismiss = useCallback(() => {
    const newState = {
      ...signupState,
      dismissCount: signupState.dismissCount + 1,
      lastPromptAt: signupState.responseCount,
    };
    setSignupState(newState);
    saveSignupState(newState);
    
    // Remove the signup form message
    setMessages((prev) => prev.filter((m) => !m.isSignupForm));
  }, [signupState]);

  const handleSignupComplete = useCallback(() => {
    const newState = { ...signupState, hasSignedUp: true };
    setSignupState(newState);
    saveSignupState(newState);
    
    // Remove signup form and add confirmation message
    setMessages((prev) => {
      const filtered = prev.filter((m) => !m.isSignupForm);
      return [
        ...filtered,
        {
          id: `signup-confirm-${Date.now()}`,
          role: 'assistant',
          content: `Thanks, ${userContext?.name || 'friend'}! Let's continue our conversation. 😊`,
          timestamp: new Date(),
        },
      ];
    });
  }, [signupState, userContext?.name]);

  const sendMessage = useCallback(
    async (content: string) => {
      if (!content.trim() || isLoading) return;

      const userMessage: Message = {
        id: `user-${Date.now()}`,
        role: 'user',
        content: content.trim(),
        timestamp: new Date(),
      };

      const assistantMessage: Message = {
        id: `assistant-${Date.now()}`,
        role: 'assistant',
        content: '',
        timestamp: new Date(),
        isStreaming: true,
        sources: [],
      };

      setMessages((prev) => [...prev, userMessage, assistantMessage]);
      setIsLoading(true);

      let fullContent = '';
      const sources: string[] = [];

      await streamChat(
        content,
        userContext,
        (chunk: StreamChunk) => {
          if (chunk.type === 'content') {
            fullContent += chunk.data;
            setMessages((prev) => {
              const updated = [...prev];
              const last = updated[updated.length - 1];
              if (last.role === 'assistant' && !last.isSignupForm) {
                last.content = fullContent;
              }
              return updated;
            });
          } else if (chunk.type === 'source') {
            sources.push(chunk.data);
          } else if (chunk.type === 'error') {
            setMessages((prev) => {
              const updated = [...prev];
              const last = updated[updated.length - 1];
              if (last.role === 'assistant' && !last.isSignupForm) {
                last.content = chunk.data;
                last.isError = true;
                last.isStreaming = false;
              }
              return updated;
            });
          }
        },
        () => {
          setMessages((prev) => {
            const updated = [...prev];
            const last = updated[updated.length - 1];
            if (last.role === 'assistant' && !last.isSignupForm) {
              last.isStreaming = false;
              last.sources = sources;
            }
            return updated;
          });
          setIsLoading(false);

          // Update response count and check if we should show signup form
          const newResponseCount = signupState.responseCount + 1;
          const newState = { ...signupState, responseCount: newResponseCount };
          setSignupState(newState);
          saveSignupState(newState);

          // Check if we should show signup form after this response
          if (shouldShowSignupForm(newResponseCount)) {
            setTimeout(() => {
              injectSignupForm();
            }, 500); // Small delay for better UX
          }
        },
        () => {
          setMessages((prev) => {
            const updated = [...prev];
            const last = updated[updated.length - 1];
            if (last.role === 'assistant' && !last.isSignupForm) {
              last.content = "I'm having trouble responding right now. Please try again in a moment.";
              last.isError = true;
              last.isStreaming = false;
            }
            return updated;
          });
          setIsLoading(false);
        }
      );
    },
    [isLoading, userContext, signupState, shouldShowSignupForm, injectSignupForm]
  );

  const clearMessages = useCallback(() => {
    setMessages([getWelcomeMessage(userContext?.name)]);
  }, [userContext?.name]);

  return {
    messages,
    isLoading,
    sendMessage,
    clearMessages,
    handleSignupDismiss,
    handleSignupComplete,
  };
}
