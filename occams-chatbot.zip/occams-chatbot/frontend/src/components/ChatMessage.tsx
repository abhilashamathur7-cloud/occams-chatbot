import { User, Bot, ExternalLink } from 'lucide-react';
import { Message } from '../types';
import SignupForm from './SignupForm';

interface Props {
  message: Message;
  onSignupSubmit?: (name: string, email: string) => void;
  onSignupDismiss?: () => void;
}

export default function ChatMessage({ message, onSignupSubmit, onSignupDismiss }: Props) {
  const isUser = message.role === 'user';

  // Render signup form if this is a signup form message
  if (message.isSignupForm && onSignupSubmit && onSignupDismiss) {
    return <SignupForm onSubmit={onSignupSubmit} onDismiss={onSignupDismiss} />;
  }

  return (
    <div className={`flex gap-3 ${isUser ? 'flex-row-reverse' : ''}`}>
      {/* Avatar */}
      <div
        className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
          isUser ? 'bg-blue-600' : 'bg-gray-200'
        }`}
      >
        {isUser ? (
          <User size={16} className="text-white" />
        ) : (
          <Bot size={16} className="text-gray-600" />
        )}
      </div>

      {/* Content */}
      <div
        className={`max-w-[80%] px-4 py-3 rounded-2xl ${
          isUser
            ? 'bg-blue-600 text-white rounded-tr-sm'
            : 'bg-white text-gray-800 rounded-tl-sm shadow-sm'
        } ${message.isError ? 'bg-red-100 text-red-700' : ''}`}
      >
        <p className="text-sm whitespace-pre-wrap">
          {message.content}
          {message.isStreaming && (
            <span className="inline-block w-2 h-4 bg-current ml-1 animate-pulse" />
          )}
        </p>

        {/* Sources */}
        {message.sources && message.sources.length > 0 && (
          <div className="mt-2 pt-2 border-t border-gray-100">
            <p className="text-xs text-gray-500 mb-1">Sources:</p>
            {message.sources.map((url, i) => (
              <a
                key={i}
                href={url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 text-xs text-blue-600 hover:underline"
              >
                <ExternalLink size={10} />
                {(() => {
                  try {
                    return new URL(url).pathname || '/';
                  } catch {
                    return url;
                  }
                })()}
              </a>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
