import { useState, useRef, useEffect } from 'react';
import { MessageCircle, X } from 'lucide-react';
import { useChat } from '../useChat';
import { UserContext } from '../types';
import ChatMessage from './ChatMessage';
import ChatInput from './ChatInput';
import { captureLead } from '../api';

interface Props {
  userContext: UserContext | null;
  onUserSignup?: (name: string, email: string) => void;
}

export default function ChatWidget({ userContext, onUserSignup }: Props) {
  const [isOpen, setIsOpen] = useState(false);
  const {
    messages,
    isLoading,
    sendMessage,
    handleSignupDismiss,
    handleSignupComplete,
  } = useChat(userContext);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSignupSubmit = async (name: string, email: string) => {
    // Save lead to backend
    if (userContext?.sessionId) {
      await captureLead(name, email, userContext.sessionId);
    }
    
    // Notify parent component to update user context
    if (onUserSignup) {
      onUserSignup(name, email);
    }
    
    // Mark signup as complete in chat
    handleSignupComplete();
  };

  return (
    <>
      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-20 right-4 w-96 h-[500px] bg-white rounded-2xl shadow-2xl flex flex-col overflow-hidden z-50">
          {/* Header */}
          <div className="bg-blue-600 text-white px-4 py-3 flex items-center justify-between">
            <div>
              <h3 className="font-semibold">Occams Advisory</h3>
              <p className="text-xs text-blue-100">
                {userContext?.name ? `Hi, ${userContext.name}!` : 'Ask me anything'}
              </p>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="p-1 hover:bg-blue-500 rounded"
            >
              <X size={20} />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
            {messages.map((msg) => (
              <ChatMessage
                key={msg.id}
                message={msg}
                onSignupSubmit={handleSignupSubmit}
                onSignupDismiss={handleSignupDismiss}
              />
            ))}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <ChatInput onSend={sendMessage} isLoading={isLoading} />
        </div>
      )}

      {/* Toggle Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-4 right-4 w-14 h-14 bg-blue-600 text-white rounded-full shadow-lg flex items-center justify-center hover:bg-blue-700 transition-colors z-50"
      >
        {isOpen ? <X size={24} /> : <MessageCircle size={24} />}
      </button>
    </>
  );
}
