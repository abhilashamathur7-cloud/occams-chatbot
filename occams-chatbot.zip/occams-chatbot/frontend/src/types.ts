export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  sources?: string[];
  isStreaming?: boolean;
  isError?: boolean;
  isSignupForm?: boolean;
}

export interface UserContext {
  name: string;
  email: string;
  sessionId: string;
  signedUpAt?: string;
}

export interface SignupState {
  hasSignedUp: boolean;
  dismissCount: number;
  responseCount: number;
  lastPromptAt: number;
}

export interface StreamChunk {
  type: 'content' | 'source' | 'done' | 'error';
  data: string;
}

export interface LeadCaptureRequest {
  name: string;
  email: string;
  session_id: string;
}

export interface LeadCaptureResponse {
  id: number;
  name: string;
  email: string;
  created_at: string;
}
